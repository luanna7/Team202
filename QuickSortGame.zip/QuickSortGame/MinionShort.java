import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MinionShort here.
 * This is the short minion which pick the lower number in the sequence.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MinionShort extends Minions
{
    /**
     * Act - do whatever the MinionShort wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
        // Add your action code here.
    public MinionShort()
    {
        GreenfootImage image = getImage() ;
        image.scale( 30, 30 ) ; 
    }

  
}
