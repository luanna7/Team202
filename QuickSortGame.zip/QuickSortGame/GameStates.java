/**
 * Write a description of class GameStates here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public enum GameStates {
    BeforeStart, InitArray, PivotInit, EndShortMinion, EndTallMinion, BeforeSwap, DoneState, EndGame
}
