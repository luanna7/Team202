/**
 * Write a description of class EndGameState here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class EndGameState extends GameState{
    public EndGameState(GameStateManager gm) {
        super(gm);
    }
}
