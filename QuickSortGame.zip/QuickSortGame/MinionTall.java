import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * This is the tall minion, which will pick the numbers higher than the pivot.
 * 
 * @author Jiheng Lu
 * @version 9/24/2016
 */
public class MinionTall extends Minions
{
    /**
     * Act - do whatever the MinionTall wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */

    public MinionTall()
    {
        GreenfootImage image = getImage() ;
        image.scale( 30, 30 ) ; 
    }
    

}
