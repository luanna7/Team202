import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class toprank here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class toprank extends Actor
{
    /**
     * Act - do whatever the toprank wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
     public toprank()
    {
        GreenfootImage image = getImage() ;
        image.scale( 250, 80 ) ; 
    }
    public void act() 
    {
        // Add your action code here.
    }    
}
