/**
 * Write a description of class GameStateInterface here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface GameStateInterface {
    public void clickNumber();
    public void setPivot();
    public void clickShortMinion();
    public void clickTallMinion();
    public void clickSwap();
    public void clickDone();
    public void submit();
    public void gotoInitArray();
}
